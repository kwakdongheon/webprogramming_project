<?php
session_start();
require_once 'includes/db.php';
// calendar.js가 캘린더 데이터를 불러오는 데 DB가 필요할 수 있습니다.
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LifeLog - 나의 일상 기록</title>
    <link rel="stylesheet" href="./public/css/calendar.css">
    <style>
        /* index.php는 캘린더 뷰를 기본으로 합니다. */
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php">
                <img src="./public/images/logo.png" alt="LifeLog" class="logo-img">
                <span class="logo-title">LifeLog</span>
            </a>
        </div>
        
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-info" style="display:flex; gap:20px; align-items:center;">
                <div class="view-toggle">
                    <button class="toggle-btn active" id="calendarToggle" onclick="location.href='index.php'">📅 캘린더</button>
                    <button class="toggle-btn" id="listToggle" onclick="location.href='posts.php'">📋 전체 기록</button>
                </div>
                <span class="user-badge">@<?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <button class="btn btn-secondary" onclick="location.href='views/write_screen.php'">✏️ 기록하기</button>
                <button class="btn logout-btn" onclick="location.href='logout.php'">로그아웃</button>
            </div>
        <?php else: ?>
            <div class="user-info">
                <button class="btn btn-secondary" onclick="location.href='views/login.php'">로그인</button>
            </div>
        <?php endif; ?>
    </header>

    <main>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="landing-container" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:80vh; text-align:center;">
                <div style="font-size: 5rem; margin-bottom: 20px;">📅✨</div>
                <h2 style="font-size: 3rem; color:var(--secondary); margin-bottom:10px;">나의 하루를<br>예쁘게 기록하세요</h2>
                <p style="color:#666; margin-bottom:30px;">
                    맛집, 여행, 취미, 그리고 소소한 일상까지.<br>
                    LifeLog 캘린더에 당신의 이야기를 채워보세요.
                </p>
                <div>
                    <button class="btn btn-secondary" style="padding:15px 40px; font-size:1.2rem;" onclick="location.href='views/register.php'">시작하기</button>
                    <button class="btn" style="padding:15px 40px; font-size:1.2rem; background:white; color:var(--primary); border:2px solid var(--primary);" onclick="location.href='views/login.php'">로그인</button>
                </div>
            </div>

        <?php else: ?>
            <div id="calendarView" class="main-layout" style="display:grid;">
                
                <aside class="sidebar">
                    <div class="calendar-header">
                        <button id="prevMonth" class="nav-btn">◀</button>
                        <h2 id="currentYearMonth" class="date-display">2025년 12월</h2>
                        <button id="nextMonth" class="nav-btn">▶</button>
                    </div>
                    <div class="calendar-grid" id="calendarGrid">
                        </div>
                </aside>

            <section class="feed-area">
                <div class="feed-header">
                    <h3 id="detailTitle">오늘의 기록 📝</h3>
                    
                    <div class="category-filter" id="calendarCategoryFilter">
                        <button class="filter-btn active" data-category="all">전체</button>
                        <button class="filter-btn" data-category="맛집">🍴 맛집</button>
                        <button class="filter-btn" data-category="카페">☕ 카페</button>
                        <button class="filter-btn" data-category="여행">✈️ 여행</button>
                        <button class="filter-btn" data-category="취미">🎨 취미</button>
                        <button class="filter-btn" data-category="일상">📝 일상</button>
                    </div>
                </div>
                
                <div id="feedContainer" class="post-list">
                    <div class="empty-state">
                        날짜를 클릭하면<br>이야기가 펼쳐집니다 ✨
                    </div>
                </div>
            </section>
            </div>
            
            <script src="./public/js/calendar.js"></script>
        <?php endif; ?>
    </main>
</body>
</html>