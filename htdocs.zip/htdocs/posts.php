<?php
require_once 'includes/auth_guard.php';
require_once 'includes/db.php';

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM posts WHERE user_id=? ORDER BY date DESC");
$stmt->execute([$user_id]);
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>내 기록 목록 - LifeLog</title>
    <link rel="stylesheet" href="./public/css/calendar.css">
</head>
<body>

<!-- 헤더 -->
<header>
    <div class="logo">
        <a href="index.php">
            <img src="./public/images/logo.png" alt="LifeLog" class="logo-img">
            <span class="logo-title">LifeLog</span>
        </a>
    </div>

    <div class="user-info" style="display:flex; gap:20px; align-items:center;">
        <div class="view-toggle">
            <button class="toggle-btn" id="calendarToggle" onclick="switchView('calendar')">📅 캘린더</button>
            <button class="toggle-btn active" id="listToggle" onclick="switchView('list')">📋 전체 기록</button>
        </div>

        <span class="user-badge">@<?php echo htmlspecialchars($_SESSION['username']); ?></span>

        <button class="btn btn-secondary" onclick="location.href='views/write_screen.php'">✏️ 기록하기</button>
        <button class="btn logout-btn" onclick="location.href='logout.php'">로그아웃</button>
    </div>
</header>

<main>

    <!-- 캘린더 뷰 -->
    <div id="calendarView" class="main-layout" style="display:none;">

        <!-- 1. 왼쪽 사이드바 (캘린더) -->
        <aside class="sidebar">
            <div class="calendar-header">
                <button id="prevMonth" class="nav-btn">◀</button>
                <h2 id="currentYearMonth" class="date-display">2025년 12월</h2>
                <button id="nextMonth" class="nav-btn">▶</button>
            </div>

            <div class="calendar-grid" id="calendarGrid">
                <!-- JS가 채움 -->
            </div>
        </aside>

        <!-- 2. 오른쪽 피드 영역 -->
        <section class="feed-area">
            <div class="feed-header">
                <h3 id="detailTitle">오늘의 기록 📝</h3>
            </div>

            <div id="feedContainer" class="post-list">
                <div class="empty-state">
                    날짜를 클릭하면<br>이야기가 펼쳐집니다 ✨
                </div>
            </div>
        </section>

    </div>


    <!-- 전체 기록 보기 -->
    <div id="listView" style="display:block; max-width: 1000px; margin: 40px auto; padding: 0 20px;">

        <h2 style="font-size: 2rem; color: var(--secondary); margin-bottom: 30px;">
            📋 나의 모든 기록
        </h2>

        <!-- 카테고리 필터 -->
        <div class="category-filter" style="margin-bottom: 20px;">
            <button class="filter-btn active" onclick="filterListView('all')">전체</button>
            <button class="filter-btn" onclick="filterListView('맛집')">🍴 맛집</button>
            <button class="filter-btn" onclick="filterListView('카페')">☕ 카페</button>
            <button class="filter-btn" onclick="filterListView('여행')">✈️ 여행</button>
            <button class="filter-btn" onclick="filterListView('취미')">🎨 취미</button>
            <button class="filter-btn" onclick="filterListView('일상')">📝 일상</button>
        </div>

        <?php if(count($posts) === 0): ?>
            <div class="empty-state" style="margin-top: 60px;">
                <div style="font-size: 4rem; margin-bottom: 20px;">📝</div>
                <p style="font-size: 1.2rem;">작성된 기록이 없습니다.</p>
                <button class="btn btn-secondary" style="margin-top: 20px;"
                        onclick="location.href='views/write_screen.php'">첫 기록 시작하기</button>
            </div>
        <?php else: ?>

            <div class="post-list" id="postListContainer" style="flex-direction: column; gap: 20px;">

                <?php foreach($posts as $p): ?>
                    <div class="polaroid-card post-item"
                         data-category="<?= htmlspecialchars($p['category']) ?>"
                         style="min-width: 100%; max-width: 100%;">

                        <div class="card-header">
                            <div class="card-title">
                                <?= htmlspecialchars($p['title'] ?: "[제목 없음]") ?>
                            </div>

                            <div class="card-meta">
                                <span class="rating-star"><?= str_repeat('★', intval($p['rating'])) ?></span> |
                                <span><?= htmlspecialchars($p['category'] ?? '기타') ?></span>
                            </div>
                        </div>
